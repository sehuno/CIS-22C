Name: Sehun Eric Oh
Class: 22C 
Assignment: HW5

*NOTE* The static main and tester functions are listed under the Color.java file, with the output commented out at the bottom. 

To compile the program, in the directory containing the source files, run 
	
	sh hw

	or 

commands

	javac Color.java HashSC.java HashQP.java HashTable.java Hasher.java LList.java ListInterface.java
	java Color

